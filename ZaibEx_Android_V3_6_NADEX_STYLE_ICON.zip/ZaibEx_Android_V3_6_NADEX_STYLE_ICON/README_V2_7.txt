Transactor Android V2.7 — Urdu Classic

Built directly on V2.6 Classic Party Statement.
Changes:
- Replaced English NADEEM launcher artwork with the approved Urdu/Arabic-script Nadeem classic icon.
- Retained tap-to-open Party Statement for wallet, receivable, payable and My Expense rows.
- Retained Party Statement PDF and CSV export.
- Retained modern-classic navy / ivory / gold interface.
- No changes to ledgerCalculationV1 or transactorMessV2 storage keys.
- Money Flow, transfers, FX, My Expense/Mess linkage, manual Mess Cycle, backup/restore and migration logic remain unchanged.
