Transactor Android V2.4 — Manual Mess Cycle

Changes:
- Enhanced UI while preserving Ledger, transfer, My Expense, FX and Mess split logic.
- New Transactor launcher icon.
- App branded with ندیم صدیقی / Nadeem Siddiqui.
- Removed automatic calendar-month Mess selection.
- One active Mess Cycle stays OPEN until Create New Cycle is explicitly used.
- Creating a new cycle finalizes the current cycle and opens the next one.
- Existing/restored Mess purchases are merged into one open cycle during migration/restore.
- Existing localStorage keys remain ledgerCalculationV1 and transactorMessV2 for compatibility.
- Backup format V4 includes cycle metadata while restoring older backups remains supported.
