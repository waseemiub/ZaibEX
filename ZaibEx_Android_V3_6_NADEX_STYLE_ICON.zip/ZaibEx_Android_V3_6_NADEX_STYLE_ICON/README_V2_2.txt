Transactor Android V2.2

Changes:
- Android status/navigation safe-area fix for Ledger and Mess headers.
- Back and +Entry/+Buy controls remain below the phone status bar.
- New Ledger Transfer Between Parties feature: one action subtracts from FROM party and adds to TO party.
- Existing Ledger ADD/SUBTRACT workflow unchanged.
- Existing MESS calculations and linked share logic unchanged.
- Local-storage keys remain unchanged for data compatibility.
- Backup/restore remains compatible with TransactorBackupV2.
