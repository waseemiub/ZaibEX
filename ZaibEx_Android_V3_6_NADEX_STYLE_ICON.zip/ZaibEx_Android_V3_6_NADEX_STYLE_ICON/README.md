ZaibEx V3.6

- Separate Android package: ae.zaibex.app
- Restores the NadEx icon artwork/design and changes only the displayed name to ZaibEx.
- Preserves ZaibEx V3.5 visibility and finance logic.
