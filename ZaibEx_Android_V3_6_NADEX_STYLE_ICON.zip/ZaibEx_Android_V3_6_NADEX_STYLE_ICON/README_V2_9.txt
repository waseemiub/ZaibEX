Transactor V2.9 — Earning + Edit/Delete
- Adds permanent Earning account under Money With Me.
- Existing restored transactions named Earning automatically consolidate into that account via canonical key.
- Full-screen party statement retained.
- Tap any ledger transaction in party statement to Edit or Delete.
- Linked transfers update/delete both sides together.
- Mess-linked entries route editing/deletion through the Mess purchase to preserve consistency.
- Existing ledgerCalculationV1 and transactorMessV2 storage keys preserved for backup compatibility.
