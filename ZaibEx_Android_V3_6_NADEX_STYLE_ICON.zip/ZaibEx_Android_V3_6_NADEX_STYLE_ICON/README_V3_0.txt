Transactor V3.0 — Simplified Money + Expense Model

- Removed Earning from permanent Money With Me accounts.
- Money With Me: Cash, Mashreq, Tabby Cash.
- Added direct Add Money to Cash / Mashreq for salary, deposits or external money without adjusting another party.
- Renamed the old Mess-linked ledger account to My Share and placed it with receivables.
- Added My Expense as a ledger-only indicator showing the user’s personal allocated spend in the current expense cycle.
- My Expense opens a full-screen detail view linked directly to Monthly Expense Details purchases.
- Renamed Mess Record to Monthly Expense Details / Expense Cycle in the interface.
- Existing storage keys and backup compatibility remain unchanged.
- Existing legacy Earning transactions are preserved as an ordinary party if present; no data is deleted.
- Full-screen statements and transaction edit/delete remain available.
