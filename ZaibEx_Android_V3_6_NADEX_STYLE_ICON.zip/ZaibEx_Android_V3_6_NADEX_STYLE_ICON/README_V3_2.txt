NadEx V3.2 — Usability Fix

- Hide Details now hides Main Balance and all three section totals.
- Transaction tap opens Edit/Delete modal directly above the full-screen party statement.
- Party statement redesigned for strong outdoor readability with dark opaque cards and high-contrast text.
- Existing financial, transfer, FX, Monthly Expense Details, My Share/My Expense, backup/restore and storage logic preserved.
