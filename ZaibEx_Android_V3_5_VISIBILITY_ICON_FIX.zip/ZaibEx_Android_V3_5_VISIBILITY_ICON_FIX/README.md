# ZaibEx V3.5
Separate Android app package: ae.zaibex.app
Changes: ZaibEx launcher icon; high-contrast visibility lock for transaction details, statements, expenses, tables and modals.
