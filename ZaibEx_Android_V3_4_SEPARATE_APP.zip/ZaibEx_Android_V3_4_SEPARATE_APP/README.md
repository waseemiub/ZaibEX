# ZaibEx Android V3.4 — Separate App

ZaibEx is an independent Android application and can be installed alongside NadEx.

- Application ID / namespace: `ae.zaibex.app`
- Display name: `ZaibEx`
- Version: 3.4 (versionCode 34)
- NadEx remains independent under `ae.transactor.app`.
- ZaibEx has its own Android app sandbox, WebView localStorage, and Downloads/ZaibEx output folder.
- Hard Money: Cash, Meezan Bank, Askari Bank.
- Open Source into Hard Money: classify as Income or Money I Owe.
- My Monthly Expenses is a one-person expense section excluded from Main Balance.
- Expenses can be funded by Hard Money or Open Source; Open Source creates Money I Owe automatically.
